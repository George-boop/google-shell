#!/bin/bash
. elib.sh
clear
while :
do
    cat $pipename > /dev/null #get clear command
    clear 
    cat $pipename
done