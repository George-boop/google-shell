pipename=.esearchfifo
