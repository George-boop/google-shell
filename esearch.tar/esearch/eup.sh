#!/bin/bash
. elib.sh

trap 'pkill -P $PPID' SIGINT SIGTERM

while :
do
    clear
    read -p "Enter search string: " qstring
    echo "clear" > $pipename #send clear command
    qstring=$(echo "${qstring}" | tr ' ' '+')
    curl \
        -A 'Mozilla/5.0 (MSIE; Windows 10)'  \
        "https://www.google.com/search?q=$qstring" | html2text > $pipename
done