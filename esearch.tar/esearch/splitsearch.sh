#!/bin/bash
##!/usr/bin/bash

#give permission: chmod +x edown.sh eup.sh splitsearch.sh 

trap 'pkill  -P $$' SIGINT SIGTERM



. elib.sh 
#check and create that named pipe exist to communicate between eup and edown scripts
     
if [ ! -p $pipename ]; then
   mkfifo "${pipename}" || exit
   #create pipe if necessary
fi

#creating tmux session = split into two windows
session="esession"
tmux kill-session -t $session >& /dev/null 

tmux new-session -d -s $session
tmux split-window -v -p 70 

window=${session}:0
pane0=${window}.0
pane1=${window}.1
tmux send-keys -t "$pane0" C-z './eup.sh' Enter
tmux send-keys -t "$pane1" C-z './edown.sh' Enter
tmux select-pane -t "$pane0"
tmux select-window -t "$window"
tmux attach-session -t "$session"




